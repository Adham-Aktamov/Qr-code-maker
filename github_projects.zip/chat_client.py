import socket

def start_client(host="127.0.0.1", port=12345):
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((host, port))

    while True:
        msg = input("Xabar yuboring: ")
        if msg.lower() == "exit":
            break
        client.sendall(msg.encode())
        response = client.recv(1024).decode()
        print("Javob:", response)

    client.close()

if __name__ == "__main__":
    start_client()

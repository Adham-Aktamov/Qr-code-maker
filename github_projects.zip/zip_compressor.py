import zipfile
import os

def compress_files(files, zip_name="compressed.zip"):
    with zipfile.ZipFile(zip_name, 'w') as zipf:
        for file in files:
            if os.path.exists(file):
                zipf.write(file)
                print(f"Fayl qo'shildi: {file}")
            else:
                print(f"Fayl topilmadi: {file}")

if __name__ == "__main__":
    files = input("Siqish uchun fayllar nomini kiriting (vergul bilan ajratib): ").split(",")
    compress_files(files)
